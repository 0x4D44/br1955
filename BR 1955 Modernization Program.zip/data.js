// BR fleet composition — figures drawn from RCTS Locomotive Stock Books
// (totals at year-end). Steam numbers are exact; diesel/electric numbers
// for in-between years are linearly interpolated where the source only
// gives milestones (1954, 1955, 1959, 1962, 1964, 1966, 1968).
// Electric figures are rough — BR-EE shunters early, AL1–AL5 from c.1960.

window.FLEET_DATA = [
  // year, steam, diesel, electric
  { y: 1948, s: 20023, d:   60, e:  20 },
  { y: 1949, s: 19900, d:   90, e:  30 },
  { y: 1950, s: 19800, d:  130, e:  45 },
  { y: 1951, s: 19503, d:  180, e:  60 },
  { y: 1952, s: 19300, d:  220, e:  75 },
  { y: 1953, s: 19100, d:  260, e:  90 },
  { y: 1954, s: 18420, d:  316, e: 100 },
  { y: 1955, s: 17955, d:  452, e: 110 },
  { y: 1956, s: 17522, d:  700, e: 125 },
  { y: 1957, s: 16954, d: 1100, e: 145 },
  { y: 1958, s: 16103, d: 1500, e: 170 },
  { y: 1959, s: 14457, d: 1799, e: 210 },
  { y: 1960, s: 13276, d: 2400, e: 260 },
  { y: 1961, s: 11691, d: 3050, e: 310 },
  { y: 1962, s:  8767, d: 3683, e: 360 },
  { y: 1963, s:  7050, d: 4150, e: 400 },
  { y: 1964, s:  4973, d: 4462, e: 430 },
  { y: 1965, s:  2987, d: 4750, e: 450 },
  { y: 1966, s:  1689, d: 4961, e: 470 },
  { y: 1967, s:   362, d: 4700, e: 490 },
  { y: 1968, s:     3, d: 4325, e: 510 },
  { y: 1969, s:     0, d: 4100, e: 530 },
  { y: 1970, s:     0, d: 3950, e: 545 },
  { y: 1971, s:     0, d: 3800, e: 555 },
  { y: 1972, s:     0, d: 3700, e: 560 },
];

// The Plan's projection — what BR thought would happen.
// The 1955 plan said: ~£1.24bn, complete by 1970, dieselise and electrify
// in a roughly 1-for-1 replacement of steam; the total fleet would stay
// roughly the size of the 1954 fleet because traffic was assumed stable.
// This is the line we draw as a dashed ghost — illustrative, not from
// a leaked Treasury spreadsheet.
window.PLAN_PROJECTION = [
  { y: 1955, total: 18500 },
  { y: 1958, total: 18200 },
  { y: 1962, total: 17800 },
  { y: 1966, total: 17500 },
  { y: 1970, total: 17000 },
  { y: 1972, total: 16800 },
];

// Chapter markers — each is (timeSeconds, year, label).
// Used by both the narration and the timeline ticker.
window.CHAPTERS = [
  { t:  0.0, label: "1955" },
  { t:  6.0, label: "The inheritance" },
  { t: 14.0, label: "The plan" },
  { t: 24.0, label: "The pilot scheme" },
  { t: 34.0, label: "The reappraisal" },
  { t: 44.0, label: "The replacement" },
  { t: 56.0, label: "End of steam" },
  { t: 64.0, label: "The twist" },
  { t: 74.0, label: "Solving the wrong problem" },
  { t: 84.0, label: "The lesson" },
];

window.TOTAL_DURATION = 94;
