// BR Modernisation Program — animated story
// Stacked area chart of the BR locomotive fleet, sweeping 1948 → 1972,
// with narration cards landing at key moments.

const { useMemo } = React;

// ── Theme tokens ─────────────────────────────────────────────────────────
const C = {
  bg:        '#f1eadc',   // newsprint cream
  bgDeep:    '#e8e0cf',   // chart bg
  ink:       '#1a1612',
  inkSoft:   '#5a4f3f',
  inkFaint:  '#9a8c75',
  rule:      '#d4c8b0',
  steam:     'oklch(48% 0.11 45)',     // burnt sienna
  steamSoft: 'oklch(70% 0.10 50)',
  diesel:    'oklch(48% 0.08 210)',    // slate teal
  dieselSoft:'oklch(72% 0.07 210)',
  electric:  'oklch(36% 0.11 270)',    // indigo
  electricSoft:'oklch(60% 0.10 270)',
  alarm:     'oklch(54% 0.18 25)',     // critical red
  plan:      '#9a8c75',                // dashed projection
};

const fontSerif = "'Source Serif 4', 'Source Serif Pro', Georgia, serif";
const fontSans  = "'Inter', system-ui, sans-serif";
const fontMono  = "'JetBrains Mono', ui-monospace, monospace";

// ── Chart geometry ───────────────────────────────────────────────────────
const CHART = {
  x: 100, y: 130, w: 1400, h: 540,
  yearMin: 1948, yearMax: 1972,
  valMax: 22000,
};

const yearToX = (y) =>
  CHART.x + ((y - CHART.yearMin) / (CHART.yearMax - CHART.yearMin)) * CHART.w;
const valToY = (v) =>
  CHART.y + CHART.h - (v / CHART.valMax) * CHART.h;

// Interpolate fleet at fractional year
function interpFleet(year) {
  const D = window.FLEET_DATA;
  if (year <= D[0].y) return D[0];
  if (year >= D[D.length - 1].y) return D[D.length - 1];
  const i = Math.floor(year - D[0].y);
  const frac = year - D[0].y - i;
  const a = D[i], b = D[i + 1];
  return {
    y: year,
    s: a.s + (b.s - a.s) * frac,
    d: a.d + (b.d - a.d) * frac,
    e: a.e + (b.e - a.e) * frac,
  };
}

// time(seconds) → year, with chapter-keyframed pacing
const timeToYear = interpolate(
  //  0   3.5  8    16   24   34   46   58   66   78   86  94
  [   0,  3.5, 8,   16,  24,  34,  46,  58,  66,  78,  86, 94 ],
  [1948, 1948, 1954, 1955, 1957, 1958, 1962, 1967, 1969, 1972, 1972, 1972],
  Easing.easeInOutQuad
);

// ── Build stacked area path for a layer up to year `maxYear` ─────────────
function buildAreaPath(maxYear, layer) {
  if (maxYear <= CHART.yearMin) return '';
  const top = [], bot = [];
  const step = 0.2;
  for (let y = CHART.yearMin; y <= maxYear + 0.001; y += step) {
    const yy = Math.min(y, maxYear);
    const f = interpFleet(yy);
    let lo, hi;
    if (layer === 'steam')        { lo = 0;        hi = f.s; }
    else if (layer === 'diesel')  { lo = f.s;      hi = f.s + f.d; }
    else                          { lo = f.s+f.d;  hi = f.s + f.d + f.e; }
    top.push([yearToX(yy), valToY(hi)]);
    bot.push([yearToX(yy), valToY(lo)]);
  }
  let p = `M ${top[0][0].toFixed(1)} ${top[0][1].toFixed(1)}`;
  for (let i = 1; i < top.length; i++) p += ` L ${top[i][0].toFixed(1)} ${top[i][1].toFixed(1)}`;
  for (let i = bot.length - 1; i >= 0; i--) p += ` L ${bot[i][0].toFixed(1)} ${bot[i][1].toFixed(1)}`;
  p += ' Z';
  return p;
}

// Outline (top edge) only
function buildEdgePath(maxYear, layer) {
  if (maxYear <= CHART.yearMin) return '';
  const pts = [];
  const step = 0.2;
  for (let y = CHART.yearMin; y <= maxYear + 0.001; y += step) {
    const yy = Math.min(y, maxYear);
    const f = interpFleet(yy);
    let hi;
    if (layer === 'steam')        hi = f.s;
    else if (layer === 'diesel')  hi = f.s + f.d;
    else                          hi = f.s + f.d + f.e;
    pts.push([yearToX(yy), valToY(hi)]);
  }
  return pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
}

// ── Format helpers ───────────────────────────────────────────────────────
const fmtNum = (n) => Math.round(n).toLocaleString('en-GB');

// ── Chart Component ──────────────────────────────────────────────────────
function FleetChart() {
  const t = useTime();
  const year = timeToYear(t);
  const f = interpFleet(year);

  const showPlan = t > 12;
  const planOpacity = clamp((t - 12) / 1.5, 0, 1) * (t > 88 ? clamp(1 - (t - 88)/2, 0, 1) : 1);

  // pre-build paths
  const steamPath   = useMemo(() => buildAreaPath(year, 'steam'),    [year]);
  const dieselPath  = useMemo(() => buildAreaPath(year, 'diesel'),   [year]);
  const electricPath= useMemo(() => buildAreaPath(year, 'electric'), [year]);
  const steamEdge   = useMemo(() => buildEdgePath(year, 'steam'),    [year]);
  const dieselEdge  = useMemo(() => buildEdgePath(year, 'diesel'),   [year]);
  const electricEdge= useMemo(() => buildEdgePath(year, 'electric'), [year]);

  // plan projection — dashed total fleet line ~17,000
  const planEdge = useMemo(() => {
    const P = window.PLAN_PROJECTION;
    return P.map((p, i) => `${i === 0 ? 'M' : 'L'} ${yearToX(p.y).toFixed(1)} ${valToY(p.total).toFixed(1)}`).join(' ');
  }, []);

  // Gridlines
  const gridYears = [1948, 1955, 1960, 1965, 1970];
  const gridVals  = [5000, 10000, 15000, 20000];

  // Playhead
  const playX = yearToX(year);

  return (
    <svg width="1600" height="900" style={{position:'absolute', inset:0}}>
      <defs>
        <pattern id="grain" width="3" height="3" patternUnits="userSpaceOnUse">
          <rect width="3" height="3" fill={C.bgDeep}/>
          <circle cx="1.5" cy="1.5" r="0.4" fill={C.rule} opacity="0.3"/>
        </pattern>
        <clipPath id="chartClip">
          <rect x={CHART.x - 1} y={CHART.y - 4} width={CHART.w + 2} height={CHART.h + 8}/>
        </clipPath>
      </defs>

      {/* Chart background */}
      <rect x={CHART.x} y={CHART.y} width={CHART.w} height={CHART.h}
            fill={C.bgDeep} opacity="0.55"/>

      {/* Horizontal gridlines */}
      {gridVals.map(v => (
        <g key={v}>
          <line x1={CHART.x} x2={CHART.x + CHART.w}
                y1={valToY(v)} y2={valToY(v)}
                stroke={C.rule} strokeWidth="1" strokeDasharray="2 4"/>
          <text x={CHART.x - 12} y={valToY(v) + 4}
                fontFamily={fontMono} fontSize="11"
                fill={C.inkFaint} textAnchor="end"
                style={{fontVariantNumeric:'tabular-nums'}}>
            {(v/1000).toFixed(0)}k
          </text>
        </g>
      ))}

      {/* Vertical year gridlines */}
      {gridYears.map(y => (
        <g key={y}>
          <line x1={yearToX(y)} x2={yearToX(y)}
                y1={CHART.y} y2={CHART.y + CHART.h}
                stroke={C.rule} strokeWidth="1" strokeDasharray="2 4"/>
          <text x={yearToX(y)} y={CHART.y + CHART.h + 18}
                fontFamily={fontMono} fontSize="11"
                fill={C.inkFaint} textAnchor="middle"
                style={{fontVariantNumeric:'tabular-nums'}}>
            {y}
          </text>
        </g>
      ))}

      {/* Plan projection — dashed line */}
      {showPlan && (
        <g style={{clipPath:'url(#chartClip)'}} opacity={planOpacity}>
          <path d={planEdge} fill="none" stroke={C.plan}
                strokeWidth="1.5" strokeDasharray="6 5"/>
          <text x={yearToX(1971)} y={valToY(17000) - 8}
                fontFamily={fontMono} fontSize="10"
                fill={C.plan} textAnchor="end"
                letterSpacing="0.08em">
            PROJECTED ·  THE PLAN
          </text>
        </g>
      )}

      {/* Stacked areas */}
      <g style={{clipPath:'url(#chartClip)'}}>
        <path d={steamPath}    fill={C.steam}    opacity="0.85"/>
        <path d={dieselPath}   fill={C.diesel}   opacity="0.92"/>
        <path d={electricPath} fill={C.electric} opacity="0.95"/>

        <path d={steamEdge}    fill="none" stroke={C.steam}    strokeWidth="1.5"/>
        <path d={dieselEdge}   fill="none" stroke={C.diesel}   strokeWidth="1.5"/>
        <path d={electricEdge} fill="none" stroke={C.electric} strokeWidth="1.5"/>
      </g>

      {/* Playhead — vertical line + current year */}
      <line x1={playX} x2={playX}
            y1={CHART.y} y2={CHART.y + CHART.h + 8}
            stroke={C.ink} strokeWidth="1"/>
      <circle cx={playX} cy={CHART.y + CHART.h} r="3.5" fill={C.ink}/>

      {/* Layer labels — float on the right edge of the chart */}
      {year >= 1949 && (
        <LayerLabels year={year} f={f}/>
      )}

      {/* Event annotations */}
      <Annotations time={t} year={year}/>

      {/* Frame */}
      <rect x={CHART.x} y={CHART.y} width={CHART.w} height={CHART.h}
            fill="none" stroke={C.ink} strokeWidth="1"/>

      {/* Legend — top-left of chart, always visible */}
      <ChartLegend/>
    </svg>
  );
}

function ChartLegend() {
  const items = [
    { c: C.steam,    l: "Steam" },
    { c: C.diesel,   l: "Diesel" },
    { c: C.electric, l: "Electric" },
    { c: C.plan,     l: "Planned total", dashed: true },
  ];
  const x0 = CHART.x + 14;
  const y0 = CHART.y + 18;
  return (
    <g>
      {items.map((it, i) => (
        <g key={i} transform={`translate(${x0}, ${y0 + i * 18})`}>
          {it.dashed ? (
            <line x1="0" y1="6" x2="18" y2="6"
                  stroke={it.c} strokeWidth="1.5" strokeDasharray="4 3"/>
          ) : (
            <rect x="0" y="1" width="18" height="10" fill={it.c} opacity="0.9"/>
          )}
          <text x="26" y="10"
                fontFamily={fontMono} fontSize="10"
                fill={C.ink}
                style={{letterSpacing:'0.12em', textTransform:'uppercase'}}>
            {it.l}
          </text>
        </g>
      ))}
    </g>
  );
}

// Floating layer labels at the right edge of the visible area
function LayerLabels({ year, f }) {
  const x = yearToX(year) + 12;
  const ySteam    = valToY(f.s / 2);
  const yDiesel   = valToY(f.s + f.d / 2);
  // The electric band is too thin to fit text inside, so we float the
  // electric label just above the top edge of the stack with a leader
  // dot anchoring it to the actual top of the electric layer.
  const yElecTop  = valToY(f.s + f.d + f.e);
  const yElectric = yElecTop - 10;

  const showSteam  = f.s > 800;
  const showDiesel = f.d > 800;
  const showElec   = f.e > 0;

  return (
    <g style={{pointerEvents:'none'}}>
      {showSteam && (
        <text x={x} y={ySteam} fontFamily={fontSans} fontSize="13"
              fontWeight="600" fill={C.steam}
              style={{fontVariantNumeric:'tabular-nums'}}>
          STEAM · {fmtNum(f.s)}
        </text>
      )}
      {showDiesel && (
        <text x={x} y={yDiesel} fontFamily={fontSans} fontSize="13"
              fontWeight="600" fill={C.diesel}
              style={{fontVariantNumeric:'tabular-nums'}}>
          DIESEL · {fmtNum(f.d)}
        </text>
      )}
      {showElec && (
        <g>
          <line x1={x - 6} y1={yElecTop} x2={x - 2} y2={yElectric + 2}
                stroke={C.electric} strokeWidth="1" opacity="0.6"/>
          <circle cx={x - 6} cy={yElecTop} r="2" fill={C.electric}/>
          <text x={x} y={yElectric} fontFamily={fontSans} fontSize="13"
                fontWeight="600" fill={C.electric}
                style={{fontVariantNumeric:'tabular-nums'}}>
            ELECTRIC · {fmtNum(f.e)}
          </text>
        </g>
      )}
    </g>
  );
}

// ── Chart annotations (event flags) ──────────────────────────────────────
// Each event has an anchor point on the chart (yr, anchorVal) and a label
// position (labelYr, labelVal). The label is rendered as a small stamp
// with a coloured kicker + dark title. Positions chosen to avoid overlap.
function Annotations({ time }) {
  const events = [
    { yr: 1951,    startT: 8,
      kicker: "1948 — 1954", title: ["Pre-Plan diesels are shunters,", "inherited from the Big Four"],
      anchorVal: 100, labelYr: 1948.3, labelVal: 4800,
      align: 'start', color: C.diesel },

    { yr: 1954.95, startT: 14,
      kicker: "DEC 1954", title: "Plan published",
      anchorVal: 18000, labelYr: 1953.6, labelVal: 21300,
      align: 'start', color: C.ink },

    { yr: 1957.46, startT: 26,
      kicker: "JUN 1957", title: "First pilot diesel — D8000",
      anchorVal: 1100, labelYr: 1955.7, labelVal: 5200,
      align: 'start', color: C.diesel },

    { yr: 1958.7,  startT: 34,
      kicker: "LATE 1958", title: ["Reappraisal: bulk orders", "before prototypes tested"],
      anchorVal: 16100, labelYr: 1959.5, labelVal: 21300,
      align: 'start', color: C.alarm },

    { yr: 1960.2,  startT: 42,
      kicker: "MAR 1960", title: ["Last steam loco built", "(92220 Evening Star)"],
      anchorVal: 13000, labelYr: 1961.5, labelVal: 19300,
      align: 'start', color: C.steam },

    { yr: 1963.25, startT: 50,
      kicker: "MAR 1963", title: ["Beeching: the problem", "is the network, not the engines"],
      anchorVal: 7050, labelYr: 1965, labelVal: 14500,
      align: 'start', color: C.ink },

    { yr: 1968.66, startT: 60,
      kicker: "AUG 1968", title: "Last mainline steam withdrawn",
      anchorVal: 200, labelYr: 1968.4, labelVal: 8500,
      align: 'end', color: C.steam },

    { yr: 1969.2,  startT: 66,
      kicker: "1967 — 1971", title: ["Pilot Scheme diesels withdrawn", "after 5 – 13 years"],
      anchorVal: 2200, labelYr: 1971.8, labelVal: 1100,
      align: 'end', color: C.alarm },
  ];

  return (
    <g>
      {events.map((e, i) => {
        if (time < e.startT) return null;
        const fadeIn = clamp((time - e.startT) / 0.7, 0, 1);
        const ax = yearToX(e.yr),      ay = valToY(e.anchorVal);
        const lx = yearToX(e.labelYr), ly = valToY(e.labelVal);
        const titleLines = Array.isArray(e.title) ? e.title : [e.title];
        // text dims
        const PAD_X = 8, PAD_Y = 6;
        const kickerH = 13, titleH = 16;
        const totalH = PAD_Y * 2 + kickerH + titleLines.length * titleH;
        // width — approx; we let SVG measure naturally instead
        const textAnchor = e.align;

        // Connector goes from anchor to nearest edge of label box
        return (
          <g key={i} opacity={fadeIn} style={{transition:'opacity .35s'}}>
            <line x1={ax} y1={ay} x2={lx} y2={ly + totalH/2 - PAD_Y}
                  stroke={e.color} strokeWidth="1" opacity="0.55"
                  strokeDasharray="3 3"/>
            <circle cx={ax} cy={ay} r="4" fill={e.color}/>
            <circle cx={ax} cy={ay} r="7" fill="none" stroke={e.color} strokeWidth="1" opacity="0.4"/>

            {/* Label group — no card background; text floats over chart */}
            <g>
              <text x={lx} y={ly}
                    fontFamily={fontMono} fontSize="10"
                    fontWeight="700" fill={e.color}
                    textAnchor={textAnchor}
                    style={{letterSpacing:'0.14em'}}>
                {e.kicker}
              </text>
              {titleLines.map((line, j) => (
                <text key={j}
                      x={lx} y={ly + 16 + j * 15}
                      fontFamily={fontSerif} fontSize="13.5"
                      fontWeight="600" fill={C.ink}
                      textAnchor={textAnchor}
                      style={{letterSpacing:'-0.005em'}}>
                  {line}
                </text>
              ))}
            </g>
          </g>
        );
      })}
    </g>
  );
}

// ── Masthead (top strip) ─────────────────────────────────────────────────
function Masthead() {
  const t = useTime();
  const year = timeToYear(t);
  return (
    <div style={{
      position:'absolute', left:0, right:0, top:0,
      height:104, padding:'24px 100px 0',
      borderBottom:`1px solid ${C.rule}`,
      display:'flex', alignItems:'baseline', justifyContent:'space-between',
      fontFamily: fontSerif,
    }}>
      <div>
        <div style={{
          fontFamily:fontMono, fontSize:11, letterSpacing:'0.18em',
          color:C.inkFaint, textTransform:'uppercase', marginBottom:6,
        }}>
          A Story in Locomotives · British Railways 1948 — 1972
        </div>
        <div style={{
          fontFamily:fontSerif, fontSize:34, fontWeight:600,
          color:C.ink, letterSpacing:'-0.015em', lineHeight:1,
        }}>
          The fleet that solved <em style={{fontStyle:'italic', color:C.alarm}}>the wrong problem</em>
        </div>
      </div>
      <div style={{textAlign:'right'}}>
        <div style={{
          fontFamily:fontMono, fontSize:11, letterSpacing:'0.18em',
          color:C.inkFaint, textTransform:'uppercase',
        }}>
          Year
        </div>
        <div style={{
          fontFamily:fontSerif, fontSize:48, fontWeight:600,
          color:C.ink, letterSpacing:'-0.02em', lineHeight:1,
          fontVariantNumeric:'tabular-nums',
        }}>
          {Math.floor(year)}
        </div>
      </div>
    </div>
  );
}

// ── Narration cards ──────────────────────────────────────────────────────
function NarrationBlock({ kicker, title, body, accent = C.ink }) {
  return (
    <div style={{
      maxWidth: 1100,
      borderLeft: `3px solid ${accent}`,
      paddingLeft: 22,
    }}>
      <div style={{
        fontFamily:fontMono, fontSize:11, letterSpacing:'0.2em',
        color:accent, textTransform:'uppercase', marginBottom:10,
        fontWeight:600,
      }}>
        {kicker}
      </div>
      <div style={{
        fontFamily:fontSerif, fontSize:25, fontWeight:600,
        color:C.ink, letterSpacing:'-0.012em', lineHeight:1.18,
        marginBottom:14, textWrap:'balance',
      }}>
        {title}
      </div>
      <div style={{
        fontFamily:fontSans, fontSize:15, fontWeight:400,
        color:C.inkSoft, lineHeight:1.5, textWrap:'pretty',
        maxWidth: 960,
      }}>
        {body}
      </div>
    </div>
  );
}

function NarrationStack() {
  const chapters = [
    { start: 0,   end: 7,
      kicker: "Prologue · 1948",
      title: "British Railways inherits 20,000 steam locomotives.",
      body: "Nationalised on 1 January 1948, BR runs the country's freight and passenger network almost entirely on steam — and keeps building new steam locomotives until 1960.",
      accent: C.steam },

    { start: 7,   end: 16,
      kicker: "December 1954",
      title: "The Modernisation Plan: £1.24 billion over fifteen years.",
      body: "Electrify principal main lines. Dieselise everything else. Replace 18,000 steam locomotives, modernise stations, signalling, freight yards. Restore profit by 1962.",
      accent: C.ink },

    { start: 16,  end: 26,
      kicker: "1955 — 1957 · The Pilot Scheme",
      title: "A sensible plan: test small batches, then standardise on the best.",
      body: "171 prototype diesels were ordered from a dozen manufacturers across three power types. The first wouldn't be delivered until June 1957.",
      accent: C.diesel },

    { start: 26,  end: 36,
      kicker: "Late 1958 · The Reappraisal",
      title: "BR can't wait. Orders are placed before prototypes are tested.",
      body: "Hundreds of locomotives ordered straight from the drawing board, from any builder who could deliver. The result: an unwieldy fleet of incompatible classes from competing makers.",
      accent: C.alarm },

    { start: 36,  end: 48,
      kicker: "1959 — 1966 · The Replacement",
      title: "Steam falls off a cliff. Diesels arrive in waves.",
      body: "In seven years the steam fleet drops from 16,000 to 1,700. Many engines built in the 1950s — to a 30-year design life — are scrapped after five.",
      accent: C.steam },

    { start: 48,  end: 58,
      kicker: "March 1963 · Beeching",
      title: "Halfway through the rollout, a different report arrives.",
      body: "The Reshaping of British Railways finds that one-third of the network carries one percent of the traffic. The problem was never the locomotives. It was the railway itself.",
      accent: C.ink },

    { start: 58,  end: 66,
      kicker: "11 August 1968",
      title: "The last mainline steam train runs. The Plan, on paper, is complete.",
      body: "Twelve years late and roughly £400 million over budget — but every steam engine has been replaced by a diesel or an electric. The job is done.",
      accent: C.steam },

    { start: 66,  end: 78,
      kicker: "The twist · 1967 — 1971",
      title: "The new diesels start being scrapped — some after just five years.",
      body: <span>Class 14, 15, 16, 17, 21, 23, 28 — entire Pilot Scheme designs scrapped. <em>Some diesel locomotives ordered in 1955 were withdrawn before the steam they were intended to replace.</em></span>,
      accent: C.alarm },

    { start: 78,  end: 88,
      kicker: "Solving the wrong problem",
      title: "Steam was replaced one-for-one. But the real problem was demand.",
      body: "Cars, lorries and airlines were taking the traffic. A like-for-like replacement wasn't a transformation — it was a more expensive way to do the same thing, on a network too big for the work it had left.",
      accent: C.ink },

    { start: 88,  end: 999,
      kicker: "The lesson",
      title: "Bolting new tech onto an old workflow looks like modernisation. It rarely is.",
      body: "The 1955 Plan asked how to replace each steam locomotive. The right question was what a 1965 railway should actually do — and most of the answer wasn't traction at all.",
      accent: C.alarm },
  ];

  return (
    <div style={{
      position:'absolute', left:100, right:100, top:738, bottom:30,
      display:'flex', alignItems:'flex-start',
    }}>
      {chapters.map((c, i) => (
        <Sprite key={i} start={c.start} end={c.end}>
          {({ localTime, duration }) => {
            const ENT = 0.35, EXT = 0.35;
            const dur = duration;
            let opacity = 1;
            if (localTime < ENT) {
              opacity = Easing.easeOutCubic(localTime / ENT);
            } else if (localTime > dur - EXT) {
              opacity = 1 - Easing.easeInCubic((localTime - (dur - EXT)) / EXT);
            }
            return (
              <div style={{
                position:'absolute', inset:0,
                opacity,
                willChange:'opacity',
              }}>
                <NarrationBlock kicker={c.kicker} title={c.title} body={c.body} accent={c.accent}/>
              </div>
            );
          }}
        </Sprite>
      ))}
    </div>
  );
}

// ── Chapter dots (progress along the timeline) ───────────────────────────
function ChapterTicker() {
  const t = useTime();
  const items = [
    { t: 0,  l: "Prologue"   },
    { t: 7,  l: "The Plan"   },
    { t: 16, l: "Pilot"      },
    { t: 26, l: "Reappraisal"},
    { t: 36, l: "Replacement"},
    { t: 48, l: "Beeching"   },
    { t: 58, l: "End of Steam"},
    { t: 66, l: "The Twist"  },
    { t: 78, l: "Wrong Problem"},
    { t: 88, l: "The Lesson" },
  ];
  return (
    <div style={{
      position:'absolute', left:100, right:100, top:706,
      display:'flex', gap:0, alignItems:'center',
      fontFamily:fontMono, fontSize:9, letterSpacing:'0.12em',
      color:C.inkFaint, textTransform:'uppercase',
    }}>
      {items.map((it, i) => {
        const active = t >= it.t && (i === items.length - 1 || t < items[i+1].t);
        return (
          <div key={i} style={{
            flex:1, paddingTop:8,
            borderTop: active ? `2px solid ${C.ink}` : `1px solid ${C.rule}`,
            color: active ? C.ink : C.inkFaint,
            fontWeight: active ? 700 : 500,
            transition:'all .25s',
            paddingRight:8,
          }}>
            {it.l}
          </div>
        );
      })}
    </div>
  );
}

// ── Scene root ───────────────────────────────────────────────────────────
function BRScene() {
  return (
    <div style={{
      position:'absolute', inset:0,
      background:C.bg,
      fontFamily:fontSans, color:C.ink,
    }}>
      <Masthead/>
      <FleetChart/>
      <ChapterTicker/>
      <NarrationStack/>

      {/* Bottom corner attribution */}
      <div style={{
        position:'absolute', right:100, bottom:14,
        fontFamily:fontMono, fontSize:9, letterSpacing:'0.16em',
        color:C.inkFaint, textTransform:'uppercase',
      }}>
        Source · RCTS Locomotive Stock Books · BR Annual Reports
      </div>
    </div>
  );
}

// ── Mount ────────────────────────────────────────────────────────────────
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Stage width={1600} height={900}
         duration={window.TOTAL_DURATION}
         background={C.bg}
         loop={true}
         persistKey="br-modernisation">
    <BRScene/>
  </Stage>
);
